from sqlalchemy import Column, Integer, String, Text, DateTime
from sqlalchemy.sql import func
from .database import Base

class Feedback(Base):
    __tablename__ = "feedbacks"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    language = Column(String(50))
    rating = Column(Integer, nullable=True)
    emoji = Column(String(10), nullable=True)
    voice_text = Column(Text, nullable=True)
    comment = Column(Text)
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
